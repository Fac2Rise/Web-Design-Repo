document.getElementById("submitButton").addEventListener('click', function(){
    event.preventDefault();
    alert("Thank you. Your message has been sent!");
    window.location.href = "index.html";
})